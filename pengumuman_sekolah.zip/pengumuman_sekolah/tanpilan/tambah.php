<link rel="stylesheet" href="tambah.css">
<h4>Form Data Pengumuman Sekolah</h4>
<div class="card">
    <div class="card-body">
        <form action="simpan.php" method="post">
            
            <!-- KOLOM INPUT JUDUL -->
            <div class="mb-3">
                <label class="form-label">
                    Judul :
                </label>
                <input class="form-control" type="text" name="judul" maxlength="20" placeholder="Maks. 20 karakter" required>
            </div>

            <!-- KOLOM INPUT ISI PENGUMUMAN -->
            <div class="mb-3">
                <label class="form-label">
                    Isi Pengumuman :
                </label>
                <textarea class="form-control" name="isi" rows="4" required></textarea>
            </div>

            <!-- KOLOM INPUT KATEGORI -->
            <div class="mb-3">
                <label class="form-label">
                    Kategori :
                </label>
                <select class="form-control" name="kategori" required>
                    <option value="">-- Pilih Kategori --</option>
                    <option value="Akademik">Akademik</option>
                    <option value="Umum">Umum</option>
                    <option value="Ekstrakurikuler">Ekstrakurikuler</option>
                </select>
            </div>

            <!-- KOLOM INPUT TANGGAL TERBIT -->
            <div class="mb-3">
                <label class="form-label">
                    Tanggal Terbit :
                </label>
                <input class="form-control" type="date" name="tanggal_terbit" required>
            </div>
            
            <!-- TOMBOL AKSI -->
            <div class="mb-3">
                <button class="btn btn-success" type="submit">SIMPAN</button>
                <button class="btn btn-danger" type="reset">BATAL</button>
            </div>

        </form>
    </div>
</div>