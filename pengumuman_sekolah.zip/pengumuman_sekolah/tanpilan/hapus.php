<?php
include "koneksi.php";

// Cek apakah ada ID yang dikirim
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Jalankan perintah SQL DELETE
    $query = "DELETE FROM pengumuman_sekolah_rafael WHERE id_pengumuman = '$id'";
    $execute = mysqli_query($koneksi, $query);

    if ($execute) {
        echo "<script>alert('Data berhasil dihapus!'); window.location='hapus.php?page=hapus.php';</script>";
        exit();
    } else {
        echo "<script>alert('Gagal menghapus data!'); window.location='hapus.php?page=hapus.php';</script>";
        exit();
    }
} else {
    // Jika dibuka tanpa ID, tampilkan halaman peringatan yang rapi
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Penghapusan Data</title>
    <!-- Hubungkan dengan file CSS -->
    <link rel="stylesheet" href="hapus.css">
</head>
<body>
    <div class="delete-container">
        <div class="delete-card">
            <div class="icon-warning">⚠️</div>
            <h3>Akses Ditolak</h3>
            <p>Tidak ada ID data yang dipilih untuk dihapus.</p>
            <a href="hapus.php?page=tampil" class="btn-back">Kembali ke tampil</a>
        </div>
    </div>
</body>
</html>
<?php
    exit();
}
?>
