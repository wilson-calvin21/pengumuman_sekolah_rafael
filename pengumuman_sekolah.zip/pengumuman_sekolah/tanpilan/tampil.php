<?php
if (!isset($koneksi)) {
    include "koneksi.php";
}
?>

<!-- Hubungkan dengan file CSS khusus tampilan -->
<link rel="stylesheet" href="tampil.css">

<div class="container py-4">
    <!-- Header Halaman -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h2 class="fw-bold mb-1" style="color: #2c3e50;">📢 Data Pengumuman Sekolah</h2>
            <p class="text-muted mb-0">Kelola informasi dan pengumuman resmi sekolah dengan mudah.</p>
        </div>
        <a href="dashboard.php?page=form_tambah_pengumuman" class="btn btn-success shadow-sm">
            <i class="bi bi-plus-lg"></i> + Tambah Pengumuman Baru
        </a>
    </div>

    <!-- Kartu Pembungkus Tabel -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead style="background-color: #2c3e50; color: white;">
                        <tr>
                            <th class="py-3 px-4" width="5%">No</th>
                            <th class="py-3 px-4" width="22%">Judul</th>
                            <th class="py-3 px-4" width="38%">Isi Pengumuman</th>
                            <th class="py-3 px-4" width="12%">Kategori</th>
                            <th class="py-3 px-4" width="13%">Tanggal</th>
                            <th class="py-3 px-4 text-center" width="10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?>
                        <?php 
                        $no = 1;
                        $query = "SELECT * FROM pengumuman_sekolah_rafael ORDER BY id_pengumuman DESC";
                        $result = mysqli_query($koneksi, $query);

                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                // Memberikan warna badge berbeda berdasarkan kategori
                                $badge_bg = 'bg-secondary';
                                if ($row['kategori'] == 'Akademik') {
                                    $badge_bg = 'bg-primary';
                                } elseif ($row['kategori'] == 'Ekstrakurikuler') {
                                    $badge_bg = 'bg-success';
                                } elseif ($row['kategori'] == 'Umum') {
                                    $badge_bg = 'bg-info text-dark';
                                }
                        ?>
                        <tr>
                            <td class="px-4 text-muted fw-semibold"><?php echo $no++; ?></td>
                            <td class="px-4 fw-bold text-dark"><?php echo htmlspecialchars($row['judul']); ?></td>
                            <td class="px-4 text-secondary" style="max-width: 300px; white-space: pre-line;"><?php echo htmlspecialchars($row['isi']); ?></td>
                            <td class="px-4">
                                <span class="badge <?php echo $badge_bg; ?> px-3 py-2 rounded-pill fw-normal">
                                    <?php echo htmlspecialchars($row['kategori']); ?>
                                </span>
                            </td>
                            <td class="px-4 text-muted small">
                                <i class="bi bi-calendar-event"></i> <?php echo date('d M Y', strtotime($row['tanggal_terbit'])); ?>
                            </td>
                            <td class="px-4 text-center">
                                <div class="d-flex justify-content-center gap-1">
                                    <a href="dashboard.php?page=mengubah&id=<?php echo $row['id_pengumuman']; ?>" 
                                       class="btn btn-warning btn-sm text-white px-2 py-1" 
                                       title="Edit Data">
                                       ✏️
                                    </a>
                                    <a href="dashboard.php?page=hapus_pengumuman&id=<?php echo $row['id_pengumuman']; ?>" 
                                       class="btn btn-danger btn-sm px-2 py-1" 
                                       title="Hapus Data"
                                       onclick="return confirm('Yakin ingin menghapus pengumuman ini?')">
                                       🗑️
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?>
                        <?php 
                            } 
                        } else {
                        ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <div class="text-muted py-3">
                                    <h4 class="fw-normal mb-1">📭 Belum Ada Data</h4>
                                    <p class="small text-muted">Silakan tambahkan pengumuman baru melalui tombol di atas.</p>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>