<?php
include "koneksi.php";
// 1. Cek apakah ada aksi update yang dikirim dari form
if (isset($_POST['update'])) {
    $id_pengumuman  = $_POST['id_pengumuman'];
    $judul          = $_POST['judul'];
    $isi            = $_POST['isi'];
    $kategori       = $_POST['kategori'];
    $tanggal_terbit = $_POST['tanggal_terbit'];

    // Jalankan perintah SQL UPDATE
    $query_update = "UPDATE pengumuman_sekolah_rafael SET 
                     judul = '$judul', 
                     isi = '$isi', 
                     kategori = '$kategori', 
                     tanggal_terbit = '$tanggal_terbit' 
                     WHERE id_pengumuman = '$id_pengumuman'";

    $execute = mysqli_query($koneksi, $query_update);

    if ($execute) {
        echo "<script>alert('Data berhasil diupdate!'); window.location='tampilan.php';</script>";
        exit();
    } else {
        echo "<script>alert('Gagal mengupdate data!');</script>";
    }
}

// 2. Ambil data lama berdasarkan ID yang dikirim dari URL (contoh: dashboard.php?page=edit_pengumuman&id=5)
$id = isset($_GET['id']) ? $_GET['id'] : '';
$query_select = "SELECT * FROM pengumuman_sekolah_rafael WHERE id_pengumuman = '$id'";
$result = mysqli_query($koneksi, $query_select);
$data = mysqli_fetch_assoc($result);

// Jika ID tidak ditemukan di database, kembalikan ke halaman tampil
if (!$data) {
    echo "<script>alert('Data tidak ditemukan!'); window.location='dashboard.php?page=tampilan.php';</script>";
    exit();
}
?>

<h4>Form Edit Pengumuman Sekolah</h4>
<div class="card">
    <div class="card-body">
        <!-- Arahkan action kembali ke halaman ini sendiri (atau kosongkan agar submit ke halaman saat ini) -->
        <form action="" method="post">
            
            <!-- ID disembunyikan agar sistem tahu baris mana yang di-update -->
            <input type="hidden" name="id_pengumuman" value="<?php echo $data['id_pengumuman']; ?>">

            <!-- KOLOM INPUT JUDUL -->
            <div class="mb-3">
                <label class="form-label">Judul :</label>
                <input class="form-control" type="text" name="judul" value="<?php echo $data['judul']; ?>" required>
            </div>

            <!-- KOLOM INPUT ISI PENGUMUMAN -->
            <div class="mb-3">
                <label class="form-label">Isi Pengumuman :</label>
                <textarea class="form-control" name="isi" rows="4" required><?php echo $data['isi']; ?></textarea>
            </div>

            <!-- KOLOM INPUT KATEGORI -->
            <div class="mb-3">
                <label class="form-label">Kategori :</label>
                <select class="form-control" name="kategori" required>
                    <option value="Akademik" <?php if($data['kategori'] == 'Akademik') echo 'selected'; ?>>Akademik</option>
                    <option value="Umum" <?php if($data['kategori'] == 'Umum') echo 'selected'; ?>>Umum</option>
                    <option value="Ekstrakurikuler" <?php if($data['kategori'] == 'Ekstrakurikuler') echo 'selected'; ?>>Ekstrakurikuler</option>
                </select>
            </div>

            <!-- KOLOM INPUT TANGGAL TERBIT -->
            <div class="mb-3">
                <label class="form-label">Tanggal Terbit :</label>
                <input class="form-control" type="date" name="tanggal_terbit" value="<?php echo $data['tanggal_terbit']; ?>" required>
            </div>
            
            <!-- TOMBOL AKSI -->
            <div class="mb-3">
                <!-- Perhatikan attribute name="update" di bawah ini -->
                <button class="btn btn-success" type="submit" name="update">UPDATE</button>
                <a href="./dashboard.php?page=tampil_pengumuman" class="btn btn-danger">BATAL</a>
            </div>

        </form>
    </div>
</div>