<?php
include "koneksi.php";
// 1. Koneksi ke Database MariaDB
$host = "localhost";
$user = "root";
$pass = "";
$db   = "pengumuman_sekolah_rafael";

$koneksi = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// 2. Ambil data dari tabel
$result = mysqli_query($koneksi, "SELECT * FROM pengumuman_sekolah_rafael");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Pengumuman Sekolah</title>
</head>
<body>

    <h2>Pengumuman Sekolah</h2>
    
    <!-- 3. Tampilkan data dalam bentuk tabel HTML -->
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Judul</th>
            <th>Isi</th>
            <th>Kategori</th>
            <th>Tanggal Terbit</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?php echo $row['id_pengumuman']; ?></td>
            <td><?php echo $row['judul']; ?></td>
            <td><?php echo $row['isi']; ?></td>
            <td><?php echo $row['kategori']; ?></td>
            <td><?php echo $row['tanggal_terbit']; ?></td>
        </tr>
        <?php endwhile; ?>

    </table>

</body>
</html>