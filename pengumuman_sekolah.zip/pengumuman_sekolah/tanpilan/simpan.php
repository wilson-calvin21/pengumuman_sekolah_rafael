<?php
// 1. Pastikan koneksi database sudah terhubung
if (!isset($koneksi)) {
    include "koneksi.php";
}

// 2. Tangkap data dari form dengan pengamanan dasar menggunakan mysqli_real_escape_string
$judul          = mysqli_real_escape_string($koneksi, $_POST['judul']);
$isi            = mysqli_real_escape_string($koneksi, $_POST['isi']);
$kategori       = mysqli_real_escape_string($koneksi, $_POST['kategori']);
$tanggal_terbit = mysqli_real_escape_string($koneksi, $_POST['tanggal_terbit']);

// 3. Jalankan perintah SQL INSERT ke database
$query = "INSERT INTO pengumuman_sekolah_rafael (judul, isi, kategori, tanggal_terbit) 
          VALUES ('$judul', '$isi', '$kategori', '$tanggal_terbit')";

$execute = mysqli_query($koneksi, $query);

// 4. Cek apakah proses simpan berhasil atau gagal
if ($execute) {
    echo "<script>alert('Data pengumuman berhasil disimpan!'); window.location='tampilan.php';</script>";
    exit();
} else {
    echo "<script>alert('Gagal menyimpan data!'); window.location='tambah.php';</script>";
    exit();
}
?>