<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "pengumuman_sekolah_rafael";

// Membuat koneksi
$koneksi = mysqli_connect($host, $user, $pass, $db);

// Cek apakah koneksi berhasil atau putus
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>