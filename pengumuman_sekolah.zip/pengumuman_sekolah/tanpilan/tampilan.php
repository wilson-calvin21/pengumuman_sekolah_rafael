<?php
// Panggil koneksi database
include "koneksi.php";

// Tentukan halaman default jika parameter ?page= belum ada
$page = isset($_GET['page']) ? $_GET['page'] : 'tampil';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pengumuman Sekolah</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- CSS Tambahan (Opsional) -->
    <link rel="stylesheet" href="tambah.css">
</head>
<body class="bg-light">

    <!-- NAVBAR / HAMBURGER MENU UTAMA -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold" href="dashboard.php?page=tampil">📢 Admin Sekolah</a>
            
            <!-- Tombol Hamburger untuk Layar HP/Tablet -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Daftar Menu -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php?page=tampil">Data Pengumuman</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white px-3 ms-lg-2 mt-2 mt-lg-0" href="dashboard.php?page=form_tambah">+ Tambah Data</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- AREA KONTEN UTAMA (TEMPAT FILE-FILE BERGANTI SECARA DINAMIS) -->
    <div class="container pb-5">
        <?php 
        // Satpam / Router untuk memanggil file modular berdasarkan parameter ?page=
        switch ($page) {
            case 'tampil':
                if (file_exists('tampil.php')) {
                    include 'tampil.php';
                } else {
                    echo "<div class='alert alert-danger'>File tampil.php belum dibuat!</div>";
                }
                break;

            case 'tambah':
                if (file_exists('tambah.php')) {
                    include 'tambah.php';
                } else {
                    echo "<div class='alert alert-danger'>File tambah.php belum dibuat!</div>";
                }
                break;

            case 'mengubah':
                if (file_exists('mengubah')) {
                    include 'mengubah.php';
                } else {
                    echo "<div class='alert alert-danger'>File mengubah.php belum dibuat!</div>";
                }
                break;


            case 'hapus':
                if (file_exists('hapus.php')) {
                    include 'hapus.php';
                } else {
                    echo "<div class='alert alert-danger'>File hapus.php belum dibuat!</div>";
                }
                break;

            default:
                echo "<div class='alert alert-warning text-center'><h4>Halaman tidak ditemukan!</h4><p>Silakan kembali ke menu utama.</p></div>";
                break;
        }
        ?>
    </div>

    <!-- Bootstrap 5 JavaScript Bundle (Penting agar hamburger menu bisa diklik) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>