<?php
include "koneksi.php"; // Panggil koneksi database
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Pengumuman Sekolah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <!-- NAVBAR / MENU UTAMA -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Admin Sekolah</a>
            <div class="navbar-nav">
                <!-- Jika menu ini diklik, dia akan memanggil file tampilan utama -->
                <a class="nav-link" href="dashboard.php?page=tampil_pengumuman">Data Pengumuman</a>
            </div>
        </div>
    </nav>

    <!-- AREA UTAMA (TEMPAT FILE-FILE DITAMPILKAN) -->
    <div class="container">
        <?php 
        // 1. Tangkap halaman dari URL. 
        // PENTING: Perhatikan bagian setelah tanda tanya ( ? ), itu adalah nilai default-nya!
        $page = isset($_GET['page']) ? $_GET['page'] : 'tampil_pengumuman';

        // 2. Satpam / Router yang mengatur file mana yang dipanggil
        switch ($page) {
            case 'tampil_pengumuman':
                include 'tampil_pengumuman.php'; // <--- Ini jadi tumpuan utamanya!
                break;
            case 'form_tambah_pengumuman':
                include 'tambah.php';
                break;
            case 'proses_simpan_pengumuman':
                include 'simpan.php';
                break;
            case 'mengubah':
                include 'mengubah.php';
                break;
            case 'proses_update_pengumuman':
                include 'proses_update_pengumuman.php';
                break;
            case 'hapus_pengumuman':
                include 'hapus.php';
                break;
            default:
                echo "<div class='alert alert-danger'>Halaman tidak ditemukan!</div>";
                break;
        }
        ?>
    </div>

</body>
</html>